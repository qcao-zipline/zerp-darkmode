const STYLE_ID = "zerp-dark-mode-style";
const ROOT_CLASS = "zerp-dark-mode";
const THEME_BACKGROUND = { r: 11, g: 18, b: 32 };
const THEME_SURFACE = { r: 11, g: 18, b: 32 };
const THEME_TEXT = { r: 229, g: 231, b: 235 };
const THEME_BORDER = { r: 75, g: 85, b: 99 };
const AVATAR_SURFACE = { r: 107, g: 114, b: 128 };
const AVATAR_TEXT = { r: 249, g: 250, b: 251 };

const managedElements = new Set();
const originalInlineStyles = new WeakMap();
const systemColorSchemeQuery = window.matchMedia("(prefers-color-scheme: dark)");

let observer;
let processScheduled = false;
const pendingRoots = new Set();
let rootListenersAttached = false;
let historyPatched = false;
let pendingRouteRefresh = [];
let suppressObserver = false;
let routeSettleInterval;
let systemThemeListenerAttached = false;
let currentThemeMode = "dark";
let darkModeActive = false;
const ROUTE_REFRESH_DELAYS = [120, 320, 700];
const ROUTE_SETTLE_INTERVAL_MS = 180;
const ROUTE_SETTLE_RUNS = 3;
const LARGE_MUTATION_BATCH_SIZE = 12;

function isNodeWithin(root, target) {
  return root === target || (root instanceof Node && target instanceof Node && root.contains(target));
}

function clearPendingRouteRefreshes() {
  for (const timeoutId of pendingRouteRefresh) {
    window.clearTimeout(timeoutId);
  }

  pendingRouteRefresh = [];
}

function clearRouteSettleInterval() {
  if (!routeSettleInterval) return;

  window.clearInterval(routeSettleInterval);
  routeSettleInterval = undefined;
}

function scheduleRouteRefreshes() {
  clearPendingRouteRefreshes();

  for (const delay of ROUTE_REFRESH_DELAYS) {
    const timeoutId = window.setTimeout(() => {
      handleRootRefresh();
      scheduleProcessing(document.documentElement);
    }, delay);

    pendingRouteRefresh.push(timeoutId);
  }
}

function normalizeProcessingRoot(root) {
  if (
    root === document ||
    root === document.documentElement ||
    root === document.body
  ) {
    return document.documentElement;
  }

  return root;
}

function injectStyle() {
  if (document.getElementById(STYLE_ID)) return;

  const style = document.createElement("style");
  style.id = STYLE_ID;
  style.textContent = `
    html.${ROOT_CLASS},
    html.${ROOT_CLASS} body {
      background: #0b1220 !important;
      color: #e5e7eb !important;
    }

    html.${ROOT_CLASS} #root,
    html.${ROOT_CLASS} #app,
    html.${ROOT_CLASS} [data-reactroot] {
      background-color: #0b1220 !important;
    }

    html.${ROOT_CLASS},
    html.${ROOT_CLASS} body,
    html.${ROOT_CLASS} button,
    html.${ROOT_CLASS} select {
      color-scheme: dark;
    }

    html.${ROOT_CLASS} section,
    html.${ROOT_CLASS} article,
    html.${ROOT_CLASS} aside,
    html.${ROOT_CLASS} nav,
    html.${ROOT_CLASS} main,
    html.${ROOT_CLASS} header,
    html.${ROOT_CLASS} footer,
    html.${ROOT_CLASS} dialog,
    html.${ROOT_CLASS} [role="dialog"],
    html.${ROOT_CLASS} [role="tablist"],
    html.${ROOT_CLASS} [role="tabpanel"],
    html.${ROOT_CLASS} [role="tab"],
    html.${ROOT_CLASS} [class*="tab"],
    html.${ROOT_CLASS} [class*="panel"],
    html.${ROOT_CLASS} [class*="attachment"],
    html.${ROOT_CLASS} [class*="Attachment"],
    html.${ROOT_CLASS} [class*="modal"],
    html.${ROOT_CLASS} [class*="drawer"],
    html.${ROOT_CLASS} [class*="popover"],
    html.${ROOT_CLASS} [class*="menu"],
    html.${ROOT_CLASS} [class*="dropdown"] {
      background-color: #0b1220 !important;
      color: #e5e7eb !important;
      border-color: #374151 !important;
    }

    html.${ROOT_CLASS} .MuiCollapse-wrapperInner,
    html.${ROOT_CLASS} .MuiCollapse-wrapperInner > div,
    html.${ROOT_CLASS} .MuiCollapse-root,
    html.${ROOT_CLASS} .MuiCollapse-root > div,
    html.${ROOT_CLASS} .MuiCardContent-root:has(.heading-block),
    html.${ROOT_CLASS} .MuiPaper-root.MuiCard-root,
    html.${ROOT_CLASS} .MuiCardActions-root,
    html.${ROOT_CLASS} .sc-jbAkgO.gFRgml,
    html.${ROOT_CLASS} .sc-jbAkgO.fGRjA-d,
    html.${ROOT_CLASS} .sc-oxoUO.eGcbyj,
    html.${ROOT_CLASS} .sc-eKpnvn.bfegnO,
    html.${ROOT_CLASS} .sc-dXYVqG.gEeofX,
    html.${ROOT_CLASS} .sc-dCZjNh.dZgnMk,
    html.${ROOT_CLASS} .sc-fxdwpw.lbgdzM,
    html.${ROOT_CLASS} .sc-kjGEIJ.kcBsgZ,
    html.${ROOT_CLASS} .sc-lbpyZL.fiortM,
    html.${ROOT_CLASS} .sc-bFYcde.gyntgu,
    html.${ROOT_CLASS} .sc-bsOfxk.cCScCG,
    html.${ROOT_CLASS} .sc-hXyblB.kQWbGf,
    html.${ROOT_CLASS} .zerp-brick,
    html.${ROOT_CLASS} [data-testid="brick-inner"],
    html.${ROOT_CLASS} .sc-jJhUpn.ePxkDo,
    html.${ROOT_CLASS} .sc-Asyiq.jrjKLz,
    html.${ROOT_CLASS} .sc-gBIzgl.ftCOgP,
    html.${ROOT_CLASS} .sc-gBIzgl.ftCOgP .inner,
    html.${ROOT_CLASS} .sc-keRagD.ceLVgk,
    html.${ROOT_CLASS} div:has(> .zerp-section),
    html.${ROOT_CLASS} div:has(> div > .zerp-section),
    html.${ROOT_CLASS} div:has(> .MuiPaper-root.MuiCard-root),
    html.${ROOT_CLASS} div:has(> .sc-dCZjNh),
    html.${ROOT_CLASS} .zerp-section,
    html.${ROOT_CLASS} .zerp-detail,
    html.${ROOT_CLASS} .zerp-hsegment,
    html.${ROOT_CLASS} div:has(> h2.heading-block),
    html.${ROOT_CLASS} section:has(> h2.heading-block) {
      background-color: #0b1220 !important;
      color: #e5e7eb !important;
      border-color: #374151 !important;
      background-clip: padding-box !important;
    }

    html.${ROOT_CLASS} .sc-jbAkgO.gFRgml,
    html.${ROOT_CLASS} .sc-jbAkgO.fGRjA-d,
    html.${ROOT_CLASS} .sc-oxoUO.eGcbyj,
    html.${ROOT_CLASS} .sc-dXYVqG.gEeofX,
    html.${ROOT_CLASS} .sc-dCZjNh.dZgnMk,
    html.${ROOT_CLASS} .sc-bFYcde.gyntgu,
    html.${ROOT_CLASS} .sc-bsOfxk.cCScCG,
    html.${ROOT_CLASS} .zerp-section,
    html.${ROOT_CLASS} .zerp-hsegment,
    html.${ROOT_CLASS} .zerp-detail,
    html.${ROOT_CLASS} .sc-dslWvo.fNQwBU,
    html.${ROOT_CLASS} .sc-hORkcV.hamBOV:has(> h2.heading-block),
    html.${ROOT_CLASS} div:has(> h2.heading-block),
    html.${ROOT_CLASS} div:has(> h2.heading-block + a),
    html.${ROOT_CLASS} h3.flex,
    html.${ROOT_CLASS} h3.flex > button,
    html.${ROOT_CLASS} button[data-radix-collection-item],
    html.${ROOT_CLASS} .sc-jbAkgO.fGRjA-d:has(.MuiPaper-root.MuiCard-root),
    html.${ROOT_CLASS} .zerp-section:has(> .MuiPaper-root.MuiCard-root),
    html.${ROOT_CLASS} .zerp-section > .MuiPaper-root.MuiCard-root,
    html.${ROOT_CLASS} .zerp-section > .MuiPaper-root.MuiCard-root > .MuiCardContent-root,
    html.${ROOT_CLASS} .zerp-section > .MuiPaper-root.MuiCard-root .MuiCollapse-root,
    html.${ROOT_CLASS} .zerp-section > .MuiPaper-root.MuiCard-root .MuiCollapse-wrapper,
    html.${ROOT_CLASS} .zerp-section > .MuiPaper-root.MuiCard-root .MuiCollapse-wrapperInner,
    html.${ROOT_CLASS} .zerp-section > .MuiPaper-root.MuiCard-root .MuiCardActions-root,
    html.${ROOT_CLASS} .zerp-section > .MuiPaper-root.MuiCard-root .sc-hORkcV.haQSCe,
    html.${ROOT_CLASS} .zerp-section > .MuiPaper-root.MuiCard-root .sc-hORkcV.hamBOV,
    html.${ROOT_CLASS} .zerp-section > .MuiPaper-root.MuiCard-root .sc-hORkcV.gZThnW,
    html.${ROOT_CLASS} .MuiPaper-root.MuiDialog-paper,
    html.${ROOT_CLASS} .MuiDialogTitle-root,
    html.${ROOT_CLASS} .MuiDialogContent-root,
    html.${ROOT_CLASS} .MuiDialogActions-root,
    html.${ROOT_CLASS} .sc-fxdwpw.lbgdzM > .sc-kjGEIJ.kcBsgZ > .sc-lbpyZL.fiortM > .sc-hXyblB,
    html.${ROOT_CLASS} .sc-fxdwpw.lbgdzM > .sc-kjGEIJ.kcBsgZ > .sc-lbpyZL.fiortM > .sc-hXyblB.sc-dMMdNl.kQWbGf.iilpFB,
    html.${ROOT_CLASS} .sc-fxdwpw.lbgdzM > .sc-bFYcde.gyntgu > .sc-hXyblB.sc-fjRZMg.kQWbGf.IdsRz,
    html.${ROOT_CLASS} .sc-fxdwpw.lbgdzM > .sc-bFYcde.gyntgu > .sc-hXyblB.kQWbGf,
    html.${ROOT_CLASS} .sc-fxdwpw.lbgdzM > .sc-bsOfxk.cCScCG > .MuiPaper-root.MuiCard-root,
    html.${ROOT_CLASS} .sc-bsOfxk.cCScCG,
    html.${ROOT_CLASS} .sc-bsOfxk.cCScCG > .MuiPaper-root.MuiCard-root.sc-kJzonb.juPlAj.css-s18byi,
    html.${ROOT_CLASS} .sc-bsOfxk.cCScCG > .MuiPaper-root.MuiCard-root .MuiCardContent-root.css-1qw96cp,
    html.${ROOT_CLASS} .sc-bsOfxk.cCScCG > .MuiPaper-root.MuiCard-root .MuiCollapse-root,
    html.${ROOT_CLASS} .sc-bsOfxk.cCScCG > .MuiPaper-root.MuiCard-root .MuiCollapse-wrapper,
    html.${ROOT_CLASS} .sc-bsOfxk.cCScCG > .MuiPaper-root.MuiCard-root .MuiCollapse-wrapperInner,
    html.${ROOT_CLASS} .sc-bsOfxk.cCScCG > .MuiPaper-root.MuiCard-root .MuiCardActions-root,
    html.${ROOT_CLASS} .sc-bsOfxk.cCScCG > .MuiPaper-root.MuiCard-root .sc-hORkcV.haQSCe,
    html.${ROOT_CLASS} .sc-bsOfxk.cCScCG > .MuiPaper-root.MuiCard-root .sc-hORkcV.hamBOV,
    html.${ROOT_CLASS} .sc-bsOfxk.cCScCG > .MuiPaper-root.MuiCard-root .sc-hORkcV.gZThnW,
    html.${ROOT_CLASS} .sc-hXyblB.sc-fjRZMg.kQWbGf.IdsRz,
    html.${ROOT_CLASS} .sc-hXyblB.sc-fjRZMg.kQWbGf.IdsRz > .sc-lmcNHa.nAJcW,
    html.${ROOT_CLASS} .sc-hXyblB.sc-fjRZMg.kQWbGf.IdsRz > .sc-eszcID.cgKeaJ,
    html.${ROOT_CLASS} .sc-hXyblB.sc-fjRZMg.kQWbGf.IdsRz .sc-ienWRC.eGJwrC,
    html.${ROOT_CLASS} .sc-fxdwpw.lbgdzM > .sc-kjGEIJ.kcBsgZ > .sc-lbpyZL.fiortM > .sc-hXyblB .zerp-detail,
    html.${ROOT_CLASS} .sc-fxdwpw.lbgdzM > .sc-kjGEIJ.kcBsgZ > .sc-lbpyZL.fiortM > .sc-hXyblB .MuiPaper-root.MuiCard-root,
    html.${ROOT_CLASS} .sc-fxdwpw.lbgdzM > .sc-kjGEIJ.kcBsgZ > .sc-lbpyZL.fiortM > .sc-hXyblB .MuiCardContent-root,
    html.${ROOT_CLASS} .sc-fxdwpw.lbgdzM > .sc-kjGEIJ.kcBsgZ > .sc-lbpyZL.fiortM > .sc-hXyblB .MuiCollapse-root,
    html.${ROOT_CLASS} .sc-fxdwpw.lbgdzM > .sc-kjGEIJ.kcBsgZ > .sc-lbpyZL.fiortM > .sc-hXyblB .MuiCollapse-wrapper,
    html.${ROOT_CLASS} .sc-fxdwpw.lbgdzM > .sc-kjGEIJ.kcBsgZ > .sc-lbpyZL.fiortM > .sc-hXyblB .MuiCollapse-wrapperInner,
    html.${ROOT_CLASS} .sc-fxdwpw.lbgdzM > .sc-kjGEIJ.kcBsgZ > .sc-lbpyZL.fiortM > .sc-hXyblB .MuiCardActions-root {
      background: #0b1220 !important;
      background-color: #0b1220 !important;
      box-shadow: none !important;
    }

    html.${ROOT_CLASS} .zerp-hsegment:has(> .sc-flQbIK.bold),
    html.${ROOT_CLASS} .zerp-hsegment:has(> .sc-flQbIK.small),
    html.${ROOT_CLASS} .zerp-hsegment:has(> .sc-jcvEFQ),
    html.${ROOT_CLASS} .zerp-hsegment:has(> .sc-flQbIK.bold) > span,
    html.${ROOT_CLASS} .zerp-hsegment:has(> .sc-flQbIK.small) > span,
    html.${ROOT_CLASS} .zerp-hsegment:has(> .sc-flQbIK.small) > span > div,
    html.${ROOT_CLASS} .zerp-hsegment:has(> .sc-jcvEFQ) > div {
      background: transparent !important;
      background-color: transparent !important;
    }

    html.${ROOT_CLASS} .ql-container,
    html.${ROOT_CLASS} .ql-editor,
    html.${ROOT_CLASS} .ql-toolbar,
    html.${ROOT_CLASS} [data-orientation="vertical"].border-b,
    html.${ROOT_CLASS} [role="region"][data-orientation="vertical"],
    html.${ROOT_CLASS} .MuiDataGrid-overlayWrapperInner,
    html.${ROOT_CLASS} .MuiDataGrid-overlay,
    html.${ROOT_CLASS} .MuiDataGrid-topContainer,
    html.${ROOT_CLASS} .MuiDataGrid-columnHeaders,
    html.${ROOT_CLASS} .MuiDataGrid-row--borderBottom,
    html.${ROOT_CLASS} .MuiDataGrid-columnHeader,
    html.${ROOT_CLASS} .MuiDataGrid-cell,
    html.${ROOT_CLASS} .MuiDataGrid-filler,
    html.${ROOT_CLASS} .MuiDataGrid-scrollbarFiller,
    html.${ROOT_CLASS} .MuiDataGrid-columnSeparator,
    html.${ROOT_CLASS} .MuiDataGrid-columnHeaderTitleContainer,
    html.${ROOT_CLASS} .MuiDataGrid-columnHeaderDraggableContainer {
      background-color: #0b1220 !important;
      color: #e5e7eb !important;
      border-color: #374151 !important;
    }

    html.${ROOT_CLASS} fieldset,
    html.${ROOT_CLASS} legend,
    html.${ROOT_CLASS} .MuiOutlinedInput-notchedOutline {
      background-color: transparent !important;
      color: inherit !important;
    }

    html.${ROOT_CLASS} .MuiOutlinedInput-notchedOutline legend,
    html.${ROOT_CLASS} .MuiOutlinedInput-notchedOutline legend span {
      color: transparent !important;
      opacity: 1 !important;
      visibility: visible !important;
    }

    html.${ROOT_CLASS} .MuiInputBase-root,
    html.${ROOT_CLASS} .MuiOutlinedInput-root {
      position: relative !important;
    }

    html.${ROOT_CLASS} .MuiInputBase-input,
    html.${ROOT_CLASS} .MuiOutlinedInput-input,
    html.${ROOT_CLASS} .MuiAutocomplete-input,
    html.${ROOT_CLASS} textarea,
    html.${ROOT_CLASS} input {
      color: #e5e7eb !important;
      -webkit-text-fill-color: #e5e7eb !important;
      caret-color: #f9fafb !important;
      position: relative !important;
      z-index: 2 !important;
    }

    html.${ROOT_CLASS} .MuiInputLabel-root,
    html.${ROOT_CLASS} .MuiFormLabel-root {
      color: #94a3b8 !important;
    }

    html.${ROOT_CLASS} .MuiInputLabel-root.Mui-focused,
    html.${ROOT_CLASS} .MuiInputLabel-root.MuiFormLabel-filled,
    html.${ROOT_CLASS} .MuiInputLabel-shrink {
      color: #93c5fd !important;
      background-color: #0b1220 !important;
      padding: 0 6px !important;
      z-index: 3 !important;
    }

    html.${ROOT_CLASS} .MuiOutlinedInput-root .MuiOutlinedInput-notchedOutline,
    html.${ROOT_CLASS} .MuiOutlinedInput-root fieldset {
      border-color: #64748b !important;
    }

    html.${ROOT_CLASS} .MuiOutlinedInput-root:hover .MuiOutlinedInput-notchedOutline,
    html.${ROOT_CLASS} .MuiOutlinedInput-root.Mui-focused .MuiOutlinedInput-notchedOutline,
    html.${ROOT_CLASS} .MuiOutlinedInput-root:hover fieldset,
    html.${ROOT_CLASS} .MuiOutlinedInput-root.Mui-focused fieldset {
      border-color: #93c5fd !important;
    }

    html.${ROOT_CLASS} .MuiAutocomplete-popper,
    html.${ROOT_CLASS} .MuiPopper-root.MuiAutocomplete-popper,
    html.${ROOT_CLASS} .MuiAutocomplete-paper,
    html.${ROOT_CLASS} .MuiAutocomplete-listbox {
      background-color: #0b1220 !important;
      color: #e5e7eb !important;
      border-color: #374151 !important;
    }

    html.${ROOT_CLASS} .MuiAutocomplete-paper {
      box-shadow: none !important;
      border: 1px solid #374151 !important;
    }

    html.${ROOT_CLASS} .MuiAutocomplete-option {
      background-color: #0b1220 !important;
      color: #e5e7eb !important;
    }

    html.${ROOT_CLASS} .MuiAutocomplete-option.Mui-focused,
    html.${ROOT_CLASS} .MuiAutocomplete-option[aria-selected="true"],
    html.${ROOT_CLASS} .MuiAutocomplete-option:hover {
      background-color: #1f2937 !important;
      color: #f8fafc !important;
    }

    html.${ROOT_CLASS} .MuiTooltip-popper,
    html.${ROOT_CLASS} .MuiPopper-root.MuiTooltip-popper,
    html.${ROOT_CLASS} .MuiTooltip-tooltip {
      background-color: #0b1220 !important;
      color: #e5e7eb !important;
      border-color: #374151 !important;
    }

    html.${ROOT_CLASS} .MuiTooltip-tooltip {
      border: 1px solid #374151 !important;
      box-shadow: none !important;
    }

    html.${ROOT_CLASS} .MuiTooltip-arrow,
    html.${ROOT_CLASS} .MuiTooltip-arrow::before {
      color: #0b1220 !important;
    }

    html.${ROOT_CLASS} .MuiRadio-root,
    html.${ROOT_CLASS} .MuiRadio-root .MuiSvgIcon-root,
    html.${ROOT_CLASS} .MuiCheckbox-root,
    html.${ROOT_CLASS} .MuiCheckbox-root .MuiSvgIcon-root {
      color: #cbd5e1 !important;
      fill: currentColor !important;
    }

    html.${ROOT_CLASS} .MuiRadio-root.Mui-checked,
    html.${ROOT_CLASS} .MuiRadio-root.Mui-checked .MuiSvgIcon-root,
    html.${ROOT_CLASS} .MuiCheckbox-root.Mui-checked,
    html.${ROOT_CLASS} .MuiCheckbox-root.Mui-checked .MuiSvgIcon-root {
      color: #93c5fd !important;
      fill: currentColor !important;
    }

    html.${ROOT_CLASS} .MuiSvgIcon-root {
      color: #e5e7eb !important;
    }

    html.${ROOT_CLASS} .MuiSvgIcon-root path,
    html.${ROOT_CLASS} .MuiSvgIcon-root rect,
    html.${ROOT_CLASS} .MuiSvgIcon-root circle,
    html.${ROOT_CLASS} .MuiSvgIcon-root polygon {
      fill: currentColor !important;
    }

    html.${ROOT_CLASS} .MuiDataGrid-booleanCell[data-testid="CheckIcon"] {
      color: #22c55e !important;
    }

    html.${ROOT_CLASS} .MuiDataGrid-booleanCell[data-testid="CloseIcon"] {
      color: #ef4444 !important;
    }

    html.${ROOT_CLASS} .MuiToggleButtonGroup-root,
    html.${ROOT_CLASS} .MuiToggleButtonGroup-grouped,
    html.${ROOT_CLASS} .MuiToggleButton-root,
    html.${ROOT_CLASS} .zerp-hsegment:has(.MuiToggleButtonGroup-root) {
      background-color: #0b1220 !important;
      border-color: #374151 !important;
    }

    html.${ROOT_CLASS} .MuiToggleButton-root {
      color: #e5e7eb !important;
    }

    html.${ROOT_CLASS} .MuiToggleButton-root.Mui-selected {
      background-color: #1f2937 !important;
      color: #93c5fd !important;
    }

    html.${ROOT_CLASS} .zerp-hsegment:has(.MuiAutocomplete-root),
    html.${ROOT_CLASS} .zerp-hsegment:has(.MuiFormControl-root),
    html.${ROOT_CLASS} .zerp-hsegment:has(.MuiFormControlLabel-root),
    html.${ROOT_CLASS} .zerp-hsegment:has(.MuiCheckbox-root),
    html.${ROOT_CLASS} form:has(.MuiAutocomplete-root) {
      background-color: #0b1220 !important;
    }

    html.${ROOT_CLASS} h1,
    html.${ROOT_CLASS} h2,
    html.${ROOT_CLASS} h3,
    html.${ROOT_CLASS} h4,
    html.${ROOT_CLASS} h5,
    html.${ROOT_CLASS} h6,
    html.${ROOT_CLASS} td,
    html.${ROOT_CLASS} th {
      color: #e5e7eb !important;
    }

    html.${ROOT_CLASS} .heading-block {
      color: #e5e7eb !important;
    }

    html.${ROOT_CLASS} a {
      color: #93c5fd !important;
    }

    html.${ROOT_CLASS} button {
      background-color: #1f2937 !important;
      color: #e5e7eb !important;
      -webkit-text-fill-color: #e5e7eb !important;
      caret-color: #f9fafb !important;
      border: 1px solid #4b5563 !important;
      box-shadow: none !important;
    }

    html.${ROOT_CLASS} button:hover,
    html.${ROOT_CLASS} button:focus-visible {
      background-color: #273449 !important;
    }

    html.${ROOT_CLASS} button.sc-beKSRx.clTBIk {
      background: transparent !important;
      border: 0 !important;
      box-shadow: none !important;
      color: #60a5fa !important;
      -webkit-text-fill-color: #60a5fa !important;
      padding: 0 !important;
      min-height: 0 !important;
      height: auto !important;
    }

    html.${ROOT_CLASS} button.sc-beKSRx.clTBIk:hover,
    html.${ROOT_CLASS} button.sc-beKSRx.clTBIk:focus-visible {
      background: transparent !important;
      color: #93c5fd !important;
      -webkit-text-fill-color: #93c5fd !important;
    }

    html.${ROOT_CLASS} button:has(> span:only-child),
    html.${ROOT_CLASS} button:has(> div:only-child) {
      background: transparent !important;
      border-color: transparent !important;
      box-shadow: none !important;
    }

    html.${ROOT_CLASS} button span,
    html.${ROOT_CLASS} button div {
      color: inherit;
    }

    html.${ROOT_CLASS} .MuiChip-root {
      color: #e5e7eb !important;
      -webkit-text-fill-color: #e5e7eb !important;
      border-radius: 9999px !important;
      border: 1px solid transparent !important;
      box-shadow: none !important;
    }

    html.${ROOT_CLASS} .MuiChip-filled,
    html.${ROOT_CLASS} .MuiChip-filledDefault {
      background-color: #334155 !important;
      border-color: #475569 !important;
    }

    html.${ROOT_CLASS} .MuiChip-outlined,
    html.${ROOT_CLASS} .MuiChip-outlinedDefault {
      background-color: rgba(51, 65, 85, 0.28) !important;
      border-color: #64748b !important;
    }

    html.${ROOT_CLASS} .MuiChip-clickable:hover,
    html.${ROOT_CLASS} .MuiChip-clickable:focus-visible,
    html.${ROOT_CLASS} .MuiChip-deletable:hover,
    html.${ROOT_CLASS} .MuiChip-deletable:focus-visible {
      background-color: #3f4d63 !important;
    }

    html.${ROOT_CLASS} .MuiChip-label,
    html.${ROOT_CLASS} .MuiChip-avatar,
    html.${ROOT_CLASS} .MuiChip-icon,
    html.${ROOT_CLASS} .MuiChip-deleteIcon {
      color: inherit !important;
      -webkit-text-fill-color: currentColor !important;
      fill: currentColor !important;
    }

    html.${ROOT_CLASS} [data-testid="delete-Not Started"] {
      background-color: #7f1d1d !important;
      border-color: #b91c1c !important;
      color: #ffffff !important;
      -webkit-text-fill-color: #ffffff !important;
    }

    html.${ROOT_CLASS} [data-testid="delete-In Progress"] {
      background-color: #854d0e !important;
      border-color: #a16207 !important;
      color: #ffffff !important;
      -webkit-text-fill-color: #ffffff !important;
    }

    html.${ROOT_CLASS} [data-testid="delete-Completed"] {
      background-color: #166534 !important;
      border-color: #15803d !important;
      color: #ffffff !important;
      -webkit-text-fill-color: #ffffff !important;
    }

    html.${ROOT_CLASS} [data-testid="issue-status-UNRESOLVED"] {
      background-color: #b91c1c !important;
      border-color: #dc2626 !important;
      color: #ffffff !important;
      -webkit-text-fill-color: #ffffff !important;
    }

    html.${ROOT_CLASS} [data-testid="issue-status-UNRESOLVED"] span {
      color: #ffffff !important;
      -webkit-text-fill-color: #ffffff !important;
    }

    html.${ROOT_CLASS} [data-testid="issue-status-RESOLVED"] {
      background-color: #15803d !important;
      border-color: #16a34a !important;
      color: #ffffff !important;
      -webkit-text-fill-color: #ffffff !important;
    }

    html.${ROOT_CLASS} [data-testid="issue-status-RESOLVED"] span {
      color: #ffffff !important;
      -webkit-text-fill-color: #ffffff !important;
    }

    html.${ROOT_CLASS} [data-zerp-runner-task="true"],
    html.${ROOT_CLASS} [data-zerp-runner-task="true"] > div,
    html.${ROOT_CLASS} [data-zerp-runner-task="true"] .zerp-hsegment,
    html.${ROOT_CLASS} [data-zerp-runner-task="true"] .sc-hORkcV.haQSCe,
    html.${ROOT_CLASS} [data-zerp-runner-task="true"] .sc-kHpCdB.ihbBdq,
    html.${ROOT_CLASS} [data-zerp-runner-task="true"] .sc-flQbIK,
    html.${ROOT_CLASS} [data-zerp-runner-task="true"] .sc-jcvEFQ {
      background-color: #1d4f7a !important;
      color: #e5e7eb !important;
      border-color: #60a5fa !important;
    }

    html.${ROOT_CLASS} [data-zerp-runner-task="true"] .zerp-hsegment,
    html.${ROOT_CLASS} [data-zerp-runner-task="true"] .sc-hORkcV.haQSCe,
    html.${ROOT_CLASS} [data-zerp-runner-task="true"] .sc-flQbIK,
    html.${ROOT_CLASS} [data-zerp-runner-task="true"] .sc-jcvEFQ {
      background: transparent !important;
    }

    html.${ROOT_CLASS} table {
      background: #0b1220 !important;
      color: #e5e7eb !important;
      border-color: #374151 !important;
    }

    html.${ROOT_CLASS} thead,
    html.${ROOT_CLASS} tbody,
    html.${ROOT_CLASS} tr,
    html.${ROOT_CLASS} td,
    html.${ROOT_CLASS} th {
      background-color: transparent !important;
      border-color: #374151 !important;
    }

    html.${ROOT_CLASS} svg,
    html.${ROOT_CLASS} svg * {
      fill-opacity: 1;
    }

    html.${ROOT_CLASS} img,
    html.${ROOT_CLASS} video,
    html.${ROOT_CLASS} canvas {
      background-color: transparent !important;
    }

    html.${ROOT_CLASS} ::selection {
      background: rgba(96, 165, 250, 0.35);
      color: #f9fafb;
    }
  `;

  document.documentElement.appendChild(style);
}

function removeInjectedStyle() {
  document.getElementById(STYLE_ID)?.remove();
}

function getStoredThemeMode(result) {
  if (result.themeMode === "dark" || result.themeMode === "light" || result.themeMode === "system") {
    return result.themeMode;
  }

  if (typeof result.darkModeEnabled === "boolean") {
    return result.darkModeEnabled ? "dark" : "light";
  }

  return "dark";
}

function shouldEnableDarkMode(themeMode) {
  return themeMode === "dark" || (themeMode === "system" && systemColorSchemeQuery.matches);
}

function parseColor(value) {
  if (!value || value === "transparent" || value === "inherit" || value === "currentColor") {
    return null;
  }

  const match = value.match(
    /rgba?\(\s*(\d+(?:\.\d+)?)\s*,\s*(\d+(?:\.\d+)?)\s*,\s*(\d+(?:\.\d+)?)\s*(?:,\s*(\d+(?:\.\d+)?)\s*)?\)/
  );

  if (!match) return null;

  return {
    r: Number(match[1]),
    g: Number(match[2]),
    b: Number(match[3]),
    a: match[4] === undefined ? 1 : Number(match[4]),
  };
}

function mixColor(source, target, amount) {
  return {
    r: Math.round(source.r * (1 - amount) + target.r * amount),
    g: Math.round(source.g * (1 - amount) + target.g * amount),
    b: Math.round(source.b * (1 - amount) + target.b * amount),
    a: source.a,
  };
}

function getBrightness(color) {
  return (color.r * 299 + color.g * 587 + color.b * 114) / 1000;
}

function rgbToHsl(color) {
  const r = color.r / 255;
  const g = color.g / 255;
  const b = color.b / 255;
  const max = Math.max(r, g, b);
  const min = Math.min(r, g, b);
  const delta = max - min;

  let h = 0;
  let s = 0;
  const l = (max + min) / 2;

  if (delta !== 0) {
    s = delta / (1 - Math.abs(2 * l - 1));

    switch (max) {
      case r:
        h = ((g - b) / delta) % 6;
        break;
      case g:
        h = (b - r) / delta + 2;
        break;
      default:
        h = (r - g) / delta + 4;
        break;
    }

    h *= 60;

    if (h < 0) {
      h += 360;
    }
  }

  return { h, s, l };
}

function hslToRgb(hsl) {
  const { h, s, l } = hsl;
  const chroma = (1 - Math.abs(2 * l - 1)) * s;
  const hueSection = h / 60;
  const x = chroma * (1 - Math.abs((hueSection % 2) - 1));

  let r1 = 0;
  let g1 = 0;
  let b1 = 0;

  if (hueSection >= 0 && hueSection < 1) {
    r1 = chroma;
    g1 = x;
  } else if (hueSection < 2) {
    r1 = x;
    g1 = chroma;
  } else if (hueSection < 3) {
    g1 = chroma;
    b1 = x;
  } else if (hueSection < 4) {
    g1 = x;
    b1 = chroma;
  } else if (hueSection < 5) {
    r1 = x;
    b1 = chroma;
  } else {
    r1 = chroma;
    b1 = x;
  }

  const match = l - chroma / 2;

  return {
    r: Math.round((r1 + match) * 255),
    g: Math.round((g1 + match) * 255),
    b: Math.round((b1 + match) * 255),
    a: 1,
  };
}

function getChannelSpread(color) {
  return Math.max(color.r, color.g, color.b) - Math.min(color.r, color.g, color.b);
}

function isNeutralColor(color) {
  return getChannelSpread(color) <= 18;
}

function toCssColor(color) {
  const alpha = color.a === undefined ? 1 : color.a;

  if (alpha >= 0.999) {
    return `rgb(${color.r}, ${color.g}, ${color.b})`;
  }

  return `rgba(${color.r}, ${color.g}, ${color.b}, ${alpha})`;
}

function rememberInlineStyle(element, property) {
  let stored = originalInlineStyles.get(element);

  if (!stored) {
    stored = {};
    originalInlineStyles.set(element, stored);
  }

  if (stored[property]) return;

  stored[property] = {
    value: element.style.getPropertyValue(property),
    priority: element.style.getPropertyPriority(property),
  };
}

function setManagedStyle(element, property, value) {
  rememberInlineStyle(element, property);
  suppressObserver = true;
  element.style.setProperty(property, value, "important");
  suppressObserver = false;
  managedElements.add(element);
}

function restoreManagedStyles() {
  for (const element of managedElements) {
    const stored = originalInlineStyles.get(element);

    if (!stored) continue;

    for (const [property, original] of Object.entries(stored)) {
      if (original.value) {
        element.style.setProperty(property, original.value, original.priority);
      } else {
        element.style.removeProperty(property);
      }
    }
  }

  managedElements.clear();
}

function isMediaElement(element) {
  return (
    element instanceof HTMLImageElement ||
    element instanceof HTMLVideoElement ||
    element instanceof HTMLCanvasElement ||
    element instanceof SVGElement
  );
}

function isTextEntryElement(element) {
  if (element instanceof HTMLTextAreaElement) return true;

  if (element instanceof HTMLInputElement) {
    const type = (element.getAttribute("type") || "text").toLowerCase();

    return !["checkbox", "radio", "range", "color", "file", "image", "submit", "reset"].includes(type);
  }

  if (element.isContentEditable) return true;
  if (element.getAttribute("role") === "textbox") return true;

  const className = typeof element.className === "string" ? element.className : "";

  return className.includes("MuiInputBase-input") || className.includes("ProseMirror") || className.includes("editor");
}

function isTextEntryWrapper(element) {
  if (!(element instanceof HTMLElement)) return false;

  const className = typeof element.className === "string" ? element.className : "";

  if (
    className.includes("MuiInputBase-root") ||
    className.includes("MuiFormControl-root") ||
    className.includes("MuiOutlinedInput-root") ||
    className.includes("MuiInputLabel-root") ||
    className.includes("MuiFormLabel-root") ||
    className.includes("MuiAutocomplete")
  ) {
    return true;
  }

  return Boolean(
    element.querySelector("input, textarea, select, [contenteditable='true'], [role='textbox']")
  );
}

function shouldAdjustBackground(styles, backgroundColor) {
  if (!backgroundColor || backgroundColor.a < 0.85) return false;
  if (styles.backgroundImage && styles.backgroundImage !== "none") return false;

  return getBrightness(backgroundColor) > 214 && isNeutralColor(backgroundColor);
}

function shouldToneColoredBackground(styles, backgroundColor) {
  if (!backgroundColor || backgroundColor.a < 0.85) return false;
  if (styles.backgroundImage && styles.backgroundImage !== "none") return false;
  if (isNeutralColor(backgroundColor)) return false;

  return getBrightness(backgroundColor) > 150;
}

function getDarkPaletteColor(backgroundColor) {
  const hsl = rgbToHsl(backgroundColor);
  const hue = hsl.h;

  let saturation = 0.42;
  let lightness = 0.24;

  if (hue >= 70 && hue < 165) {
    saturation = 0.4;
    lightness = 0.21;
  } else if (hue >= 165 && hue < 255) {
    saturation = 0.44;
    lightness = 0.22;
  } else if (hue >= 255 && hue < 330) {
    saturation = 0.38;
    lightness = 0.24;
  } else if (hue >= 25 && hue < 70) {
    saturation = 0.48;
    lightness = 0.23;
  } else {
    saturation = 0.5;
    lightness = 0.24;
  }

  return hslToRgb({
    h: hue,
    s: Math.max(saturation, Math.min(hsl.s, 0.7)),
    l: lightness,
  });
}

function shouldPreserveAccentText(textColor) {
  if (!textColor || textColor.a < 0.85) return false;
  if (isNeutralColor(textColor)) return false;

  const hsl = rgbToHsl(textColor);

  return hsl.s >= 0.28 && hsl.l >= 0.28 && hsl.l <= 0.72;
}

function shouldAdjustText(textColor, backgroundColor) {
  if (!textColor || textColor.a < 0.85) return false;
  if (getBrightness(textColor) >= 145) return false;
  if (shouldPreserveAccentText(textColor)) return false;
  if (
    backgroundColor &&
    backgroundColor.a >= 0.85 &&
    getBrightness(backgroundColor) > 150 &&
    !isNeutralColor(backgroundColor)
  ) {
    return false;
  }

  return !backgroundColor || backgroundColor.a < 0.2 || getBrightness(backgroundColor) > 120;
}

function isAvatarBadge(element, styles, backgroundColor) {
  if (!backgroundColor || backgroundColor.a < 0.85) return false;
  if (styles.backgroundImage && styles.backgroundImage !== "none") return false;
  if (styles.borderRadius === "0px") return false;

  const width = element.offsetWidth;
  const height = element.offsetHeight;

  if (!width || !height) return false;
  if (Math.abs(width - height) > 6) return false;
  if (width < 28 || width > 72) return false;

  const text = element.textContent ? element.textContent.trim() : "";

  if (!text || text.length > 3) return false;

  return isNeutralColor(backgroundColor);
}

function isRunnerTaskContainer(element) {
  if (!(element instanceof HTMLElement)) return false;

  const text = element.textContent
    ? element.textContent.replace(/\s+/g, " ").trim().toLowerCase()
    : "";

  if (!text) return false;

  const className = typeof element.className === "string" ? element.className : "";

  if (!className.includes("sc-lncAYT")) return false;

  return (
    text.includes("maintenance task requested") ||
    text.includes("maintenance task completed")
  );
}

function processElement(element) {
  if (!(element instanceof HTMLElement) || isMediaElement(element)) return;
  if (isTextEntryElement(element) || isTextEntryWrapper(element)) return;

  if (isRunnerTaskContainer(element)) {
    element.setAttribute("data-zerp-runner-task", "true");
  }

  const styles = window.getComputedStyle(element);
  const backgroundColor = parseColor(styles.backgroundColor);
  const textColor = parseColor(styles.color);
  const borderColor = parseColor(styles.borderColor);

  if (isAvatarBadge(element, styles, backgroundColor)) {
    setManagedStyle(element, "background-color", toCssColor(AVATAR_SURFACE));
    setManagedStyle(element, "color", toCssColor(AVATAR_TEXT));
    setManagedStyle(element, "border-color", toCssColor(mixColor(AVATAR_SURFACE, THEME_BORDER, 0.5)));
    setManagedStyle(element, "caret-color", toCssColor(AVATAR_TEXT));
  } else if (shouldToneColoredBackground(styles, backgroundColor)) {
    setManagedStyle(element, "background-color", toCssColor(getDarkPaletteColor(backgroundColor)));
  } else if (shouldAdjustBackground(styles, backgroundColor)) {
    setManagedStyle(element, "background-color", toCssColor(mixColor(backgroundColor, THEME_SURFACE, 0.88)));
  }

  if (shouldAdjustText(textColor, backgroundColor)) {
    setManagedStyle(element, "color", toCssColor(mixColor(textColor, THEME_TEXT, 0.9)));
    setManagedStyle(element, "caret-color", toCssColor(THEME_TEXT));
  }

  if (
    borderColor &&
    borderColor.a >= 0.85 &&
    getBrightness(borderColor) > 190 &&
    styles.borderStyle !== "none" &&
    styles.borderWidth !== "0px"
  ) {
    setManagedStyle(element, "border-color", toCssColor(mixColor(borderColor, THEME_BORDER, 0.82)));
  }
}

function enforceRootTheme() {
  setManagedStyle(document.documentElement, "background-color", toCssColor(THEME_BACKGROUND));
  setManagedStyle(document.body, "background-color", toCssColor(THEME_BACKGROUND));
  setManagedStyle(document.documentElement, "color", toCssColor(THEME_TEXT));
  setManagedStyle(document.body, "color", toCssColor(THEME_TEXT));
}

function handleRootRefresh() {
  if (!document.documentElement.classList.contains(ROOT_CLASS)) return;

  enforceRootTheme();
}

function refreshAfterRouteChange() {
  if (!document.documentElement.classList.contains(ROOT_CLASS)) return;

  handleRootRefresh();
  scheduleProcessing(document.documentElement);
  scheduleRouteRefreshes();
  clearRouteSettleInterval();

  let settleRuns = 0;
  routeSettleInterval = window.setInterval(() => {
    handleRootRefresh();
    scheduleProcessing(document.documentElement);
    settleRuns += 1;

    if (settleRuns >= ROUTE_SETTLE_RUNS) {
      clearRouteSettleInterval();
    }
  }, ROUTE_SETTLE_INTERVAL_MS);
}

function patchHistoryMethods() {
  if (historyPatched) return;

  const wrapHistoryMethod = (methodName) => {
    const original = window.history[methodName];

    window.history[methodName] = function patchedHistoryMethod(...args) {
      const result = original.apply(this, args);
      refreshAfterRouteChange();
      return result;
    };
  };

  wrapHistoryMethod("pushState");
  wrapHistoryMethod("replaceState");
  historyPatched = true;
}

function attachRootListeners() {
  if (rootListenersAttached) return;

  window.addEventListener("focus", handleRootRefresh);
  window.addEventListener("pageshow", handleRootRefresh);
  document.addEventListener("visibilitychange", handleRootRefresh);
  window.addEventListener("popstate", refreshAfterRouteChange);
  window.addEventListener("hashchange", refreshAfterRouteChange);
  patchHistoryMethods();
  rootListenersAttached = true;
}

function detachRootListeners() {
  if (!rootListenersAttached) return;

  window.removeEventListener("focus", handleRootRefresh);
  window.removeEventListener("pageshow", handleRootRefresh);
  document.removeEventListener("visibilitychange", handleRootRefresh);
  window.removeEventListener("popstate", refreshAfterRouteChange);
  window.removeEventListener("hashchange", refreshAfterRouteChange);
  clearPendingRouteRefreshes();
  clearRouteSettleInterval();
  rootListenersAttached = false;
}

function processTree(root) {
  if (!root) return;

  if (root instanceof Element) {
    processElement(root);
  }

  if (!(root instanceof Node)) return;

  const walker = document.createTreeWalker(root, NodeFilter.SHOW_ELEMENT);
  let currentNode = walker.nextNode();

  while (currentNode) {
    processElement(currentNode);
    currentNode = walker.nextNode();
  }
}

function flushProcessing() {
  processScheduled = false;

  if (!document.documentElement.classList.contains(ROOT_CLASS)) {
    pendingRoots.clear();
    return;
  }

  for (const root of pendingRoots) {
    processTree(root);
  }

  pendingRoots.clear();
}

function scheduleProcessing(root) {
  if (!root) return;

  const normalizedRoot = normalizeProcessingRoot(root);

  if (!(normalizedRoot instanceof Node)) return;

  for (const pendingRoot of pendingRoots) {
    if (isNodeWithin(pendingRoot, normalizedRoot)) {
      return;
    }
  }

  for (const pendingRoot of Array.from(pendingRoots)) {
    if (isNodeWithin(normalizedRoot, pendingRoot)) {
      pendingRoots.delete(pendingRoot);
    }
  }

  pendingRoots.add(normalizedRoot);

  if (processScheduled) return;

  processScheduled = true;
  requestAnimationFrame(flushProcessing);
}

function startObserving() {
  if (observer) return;

  observer = new MutationObserver((mutations) => {
    if (suppressObserver) return;

    for (const mutation of mutations) {
      if (mutation.type === "attributes") {
        if (mutation.target instanceof Element) {
          scheduleProcessing(mutation.target);
        }
        continue;
      }

      const addedElements = Array.from(mutation.addedNodes).filter((node) => node instanceof Element);

      if (addedElements.length > LARGE_MUTATION_BATCH_SIZE) {
        scheduleProcessing(mutation.target);
        continue;
      }

      addedElements.forEach((node) => {
        scheduleProcessing(node);
      });
    }
  });

  observer.observe(document.documentElement, {
    subtree: true,
    childList: true,
    attributes: true,
    attributeFilter: ["class", "style"],
  });
}

function stopObserving() {
  if (!observer) return;

  observer.disconnect();
  observer = undefined;
}

function enableDarkMode() {
  if (darkModeActive) return;

  darkModeActive = true;
  injectStyle();
  document.documentElement.classList.add(ROOT_CLASS);
  enforceRootTheme();
  scheduleProcessing(document.documentElement);
  startObserving();
  attachRootListeners();
}

function disableDarkMode() {
  darkModeActive = false;
  stopObserving();
  detachRootListeners();
  pendingRoots.clear();
  processScheduled = false;
  restoreManagedStyles();
  document.documentElement.classList.remove(ROOT_CLASS);
  removeInjectedStyle();
}

function handleSystemThemeChange() {
  if (currentThemeMode !== "system") return;

  if (shouldEnableDarkMode(currentThemeMode)) {
    enableDarkMode();
  } else {
    disableDarkMode();
  }
}

function attachSystemThemeListener() {
  if (systemThemeListenerAttached) return;

  systemColorSchemeQuery.addEventListener("change", handleSystemThemeChange);
  systemThemeListenerAttached = true;
}

function detachSystemThemeListener() {
  if (!systemThemeListenerAttached) return;

  systemColorSchemeQuery.removeEventListener("change", handleSystemThemeChange);
  systemThemeListenerAttached = false;
}

function applyThemeMode(themeMode) {
  currentThemeMode = themeMode;

  if (themeMode === "system") {
    attachSystemThemeListener();
  } else {
    detachSystemThemeListener();
  }

  if (shouldEnableDarkMode(themeMode)) {
    enableDarkMode();
  } else {
    disableDarkMode();
  }
}

function syncState() {
  chrome.storage.local.get({ themeMode: "dark", darkModeEnabled: true }, (result) => {
    applyThemeMode(getStoredThemeMode(result));
  });
}

syncState();

chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== "local") return;

  if (changes.themeMode) {
    applyThemeMode(getStoredThemeMode({ themeMode: changes.themeMode.newValue }));
    return;
  }

  if (changes.darkModeEnabled) {
    applyThemeMode(getStoredThemeMode({ darkModeEnabled: changes.darkModeEnabled.newValue }));
  }
});
